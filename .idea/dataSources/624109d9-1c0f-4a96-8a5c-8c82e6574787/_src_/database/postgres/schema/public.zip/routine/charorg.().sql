create function charorg() returns trigger
LANGUAGE plpgsql
AS $$
declare 
	i integer;
	j integer; 
	begin
		i = NEW.leader;
		j = (select count(*) from characterOrganization where member = i);
		if (j = 0) then
		insert into characterOrganization values ( i , NEW.org_name);
			end if;
		return new;
	end;

$$;
