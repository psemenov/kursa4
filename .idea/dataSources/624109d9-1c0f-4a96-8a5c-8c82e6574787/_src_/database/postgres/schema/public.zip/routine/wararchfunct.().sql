create function wararchfunct() returns trigger
LANGUAGE plpgsql
AS $$
declare
i integer;
begin
i = (select max(id) from place_authority where  place_authority.place_id = new.place_id );
	update place_authority set finish = new.start where id = i ;
new.finish = null; 
return new;
end;
$$;
