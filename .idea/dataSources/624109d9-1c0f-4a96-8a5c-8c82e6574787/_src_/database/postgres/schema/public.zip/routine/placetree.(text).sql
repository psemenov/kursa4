create function placetree(text) returns SETOF text
LANGUAGE SQL
AS $$
select place_name from place where location_id  = (select place_id from place where place_name = $1)
$$;
