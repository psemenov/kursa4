create function leaderchkfunct() returns trigger
LANGUAGE plpgsql
AS $$
begin
	if ((select nation_id from character where character.character_id = new.nation_leader) != new.nation_id ) then
	raise exception 'nation should have leader from the same nation';
	else return new;
	end if;
end
$$;
