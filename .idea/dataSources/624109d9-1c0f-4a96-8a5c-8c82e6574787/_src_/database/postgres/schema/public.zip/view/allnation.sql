CREATE VIEW allnation AS SELECT nation.nation_id AS id,
    nation.nation_name AS name,
    magic.m_type AS magic,
    place.place_name AS capital,
    "character".name AS leader,
    nation.n_desc AS description
   FROM ((((nation
     JOIN nationleader USING (nation_id))
     JOIN "character" ON (("character".character_id = nationleader.leader)))
     JOIN place USING (place_id))
     JOIN magic ON ((magic.m_id = nation.m_id)));
